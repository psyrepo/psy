const React = require ("react");
import Footer from "../core/components/Footer";
import Header from "../core/components/Header";

function Profile() {
     
     return (
          <div>
               <Header />
               <h1>Welcome to Profile</h1>
               <Footer />
          </div>
     );
}

export default Profile;