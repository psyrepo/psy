const React = require ("react");
import Routes from "./Routes";
const ReactDOM = require ("react-dom");

ReactDOM.render(<Routes />, document.getElementById("root"));
