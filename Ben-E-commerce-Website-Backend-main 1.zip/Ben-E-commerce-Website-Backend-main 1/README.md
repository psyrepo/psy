# BenPelu-Inc-E-commerce-Website-Frontend
 An e-commerce website created in MERN stack. Frontend is of React JS, Backend is of Node, Express JS and MongoDB is used for database.

## Description

An ecommerce store built with MERN stack, and utilizes third party API's. This ecommerce store enable two main different flows or implementations:

1. Buyers browse the store categories, products and brands
2. Admins manage and control the entire store components 


* features:
  * Node provides the backend environment for this application
  * Express middleware is used to handle requests, routes
  * Mongoose schemas to model the application data
  * EJS Templete Engine for displaying UI components

## Note 

  * This repo is just backend of website. You need frontend also. Go here for frontend -> https://github.com/.

## Demo

This application is deployed on ----. Please check it out :smile: https://-.

* Admin:Email- admin@admin.net|password- admin123
* For User ----
* User:Email- user@test.com | password- user123

* For demo purchase, use this card -> Card no.378282246310005| Exp. 12/21

## Install

Some basic Git commands are: 

```
$ git clone https://github.com/--
$ cd project
$ npm install
```

## Setup

```
 Goto .env file that include:

 - * DB_URL=YOUR_MYSQL_DB_URL
  * PORT=8000
  * SECRET=Token Secret for jsonwebtoken
  * STRIPE_MERCHANTID=YOUR_MERCHANTID
  * STRIPE_PUBLIC_KEY=YOUR_PUBLIC_KEY
  * STRIPE_PRIVATE_KEY=YOUR_PRIVATE_KEY-
  * Change the values after the equal sign"=" to yours
```

## Deployment

```
> Create a Procfile in the root directory of your application with the following command **web: npm run start:production**
```


## Simple build for production

```
$ npm run production
```

## Run the application for development

```
$ npm start
```

## Run the application for production

```
$ npm run start:production
```

## Languages & tools

- [Node](https://nodejs.org/en/)

- [Express](https://expressjs.com/)

- [MySQL](https://mysql.org/)

- [React](https://reactjs.org/)


