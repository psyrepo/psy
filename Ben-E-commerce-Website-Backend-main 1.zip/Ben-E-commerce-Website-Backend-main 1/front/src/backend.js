const API = process.env.REACT_APP_BACKEND;

export default API;